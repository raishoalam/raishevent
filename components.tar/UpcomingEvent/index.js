import './index.css'
import {useState, useEffect} from 'react'

function UpcomingEvents() {
  const [events, setEvents] = useState([])
  const [loading, setLoading] = useState(true)
  const [fetchError, setFetchError] = useState(null)

  const fetchUpcomingEvents = async () => {
    try {
      const response = await fetch(
        'https://gg-backend-assignment.azurewebsites.net/api/Events?code=FOX643kbHEAkyPbdd8nwNLkekHcL4z0hzWBGCd64Ur7mAzFuRCHeyQ==&page=1&type=upcoming',
      )
      if (!response.ok) {
        throw new Error('Failed to fetch events')
      }
      const data = await response.json()
      console.log('Fetched data:', data)
      if (Array.isArray(data)) {
        setEvents(data)
        setLoading(false)
      } else {
        throw new Error('Fetched data is not an array')
      }
    } catch (error) {
      console.error('Error fetching events:', error.message)
      setFetchError('Failed to fetch events. Please try again later.')
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchUpcomingEvents()
  }, [])

  return (
    <div>
      <h2>Upcoming Events</h2>
      {loading && <div>Loading...</div>}
      {fetchError && <div>Error: {fetchError}</div>}
      <ul>
        {events.map(event => (
          <li key={event.id}>
            <div>
              <img src={event.img_url} alt={event.name} />
            </div>
            <div>
              <strong>Name:</strong> {event.name}
            </div>
            <div>
              <strong>Date:</strong> {event.date}
            </div>
          </li>
        ))}
      </ul>
    </div>
  )
}

export default UpcomingEvents
