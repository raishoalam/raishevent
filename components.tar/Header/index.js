// Navbar.js
import {IoReorderThree, IoHeartSharp, IoLocationOutline} from 'react-icons/io5'
import {FaGreaterThan} from 'react-icons/fa6'
import {CiSearch} from 'react-icons/ci'
import './index.css'

function Navbar() {
  return (
    <nav>
      <div>
        <div className="nav-cont">
          <h1 className="nav-heading">BookUsNow</h1>
          <div>
            <button type="button" className="nav-btn">
              <IoReorderThree className="nav-icon" />
              Categories
            </button>
          </div>
          <div>
            <input
              type="search"
              placeholder="DJI phantom"
              className="nav-search"
            />
            <CiSearch className="search-icon" />
          </div>

          <p className="nav-fav">
            <IoHeartSharp className="fav-icon" />
            Favorites
          </p>
          <div>
            <button type="button" className="sign-btn">
              Sign In
            </button>
          </div>
        </div>
        <div>
          <p className="nav-loc">
            <IoLocationOutline className="loc-icon" />
            Mumbai,India <FaGreaterThan className="loc-icon" />
          </p>
        </div>
        <div className="activities-cont">
          <p className="act-pra">Live Shows</p>
          <p className="act-pra">Streams</p>
          <p className="act-pra">Movies</p>
          <p className="act-pra">Plays</p>
          <p className="act-pra">Events</p>
          <p className="act-pra">Sports</p>
          <p className="act-pra">Activities</p>
        </div>
      </div>
    </nav>
  )
}

export default Navbar
