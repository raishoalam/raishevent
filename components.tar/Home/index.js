// HomePage.js
import './index.css'
import UpcomingEvent from '../UpcomingEvent'

function HomePage() {
  return (
    <div>
      <div className="home-bg">
        <h1 className="home-heading">
          Discover Exciting Events Happening Near You-Stay Tuned for Updates!
        </h1>
        <p className="home-paragraph">
          Lorem Ipsum is simply dummy text of the printing and typesetting
          industry. Lorem Ipsum has been the industry standard dummy text ever
          since the 1500s, when an unknown printer took a galley of type and
          scrambled it to make a type specimen book.
        </p>
      </div>
      <UpcomingEvent />
    </div>
  )
}

export default HomePage
